These records were regenerated from the 47 Java files in this submission ZIP.
Runtime: OpenJDK 21.0.13 on Linux. Windows execution of run.bat was not available.

*.in: input, one response per line. *.out: actual standard output.
The application deliberately suppresses prompts when its input is redirected.
Example after compilation: java Main < evidence/TC01.in
Test_Cases.json contains the expected output checks for all 26 scenarios.
Source_SHA256.json identifies the exact Java files used for these runs.
Final_Audit_Results.json also records separate external state-invariant checks;
the external test harness is not part of the submitted application.
